import javax.swing.*;

public class Viewer {

    private Canvas canvas;

    public Viewer(){

        Controller controller = new Controller(this);
        Model model = controller.getModel();
        canvas = new Canvas(model);

        JFrame frame = new JFrame("Sokoban Game MVC Pattern!");
        frame.setSize(1100,700);
        frame.setLocation(100,50);
        frame.add("Center", canvas);
        frame.addKeyListener(controller);
        frame.setVisible(true);

    }
    public void update(){
        canvas.repaint();

    }

}
