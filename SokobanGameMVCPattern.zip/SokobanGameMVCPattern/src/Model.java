import java.awt.event.ActionEvent;

public class Model {

    private Viewer viewer;
    private int[][] desktop;
    private int indexX;
    private int indexY;
    private int indexXofGreen;
    private int indexYofGreen;
    private int[][] arrayFours;
    private boolean stateModel;


    public Model(Viewer viewer){
        this.viewer = viewer;
        desktop = new int[][]{
                {5, 5, 5, 5, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5},
                {5, 5, 5, 5, 2, 0, 0, 0, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5},
                {5, 5, 5, 5, 2, 3, 0, 0, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5},
                {5, 5, 2, 2, 2, 0, 0, 3, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5},
                {5, 5, 2, 0, 0, 3, 0, 3, 0, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5},
                {2, 2, 2, 0, 2, 0, 2, 2, 0, 2, 5, 5, 5, 2, 2, 2, 2, 2, 2},
                {2, 0, 0, 0, 2, 0, 2, 2, 0, 2, 2, 2, 2, 2, 0, 0, 4, 4, 2},
                {2, 0, 3, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 2},
                {2, 2, 2, 2, 2, 0, 2, 2, 2, 0, 2, 1, 2, 2, 0, 0, 4, 4, 2},
                {5, 5, 5, 5, 2, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2},
                {5, 5, 5, 5, 2, 2, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5},
        };
        initialization();
    }
    private void initialization(){
        stateModel = true;
        int counterOne = 0;
        int counterFour = 0;
        int counterThree = 0;
        for(int i = 0; i < desktop.length; i++){
            for(int j = 0; j<desktop[i].length; j++){
                if(desktop[i][j] == 4){
                    counterFour = counterFour + 1;
                }else if(desktop[i][j] == 1) {
                    indexX = i;
                    indexY = j;
                    counterOne = counterOne + 1;
                } else if(desktop[i][j] == 3) {
                    counterThree = counterThree + 1;
                }
            }
        }
//        if(counterFour != counterThree || counterFour >1 || counterFour >1){
//            stateModel = false;
//            return;
//        }

        if((counterThree == 0) || (counterFour == 0) ||
                ((counterThree != counterFour) || (counterOne != 1))) {
            stateModel = false;
            return;
        }
        System.out.println("Elements = " + counterFour);
        arrayFours = new int[2][counterFour];

        for(int i = 0; i < arrayFours.length; i++){
            for(int j = 0; j < arrayFours[i].length; j++){
                System.out.print(arrayFours[i][j] + "");
            }
            System.out.println();
        }
        int indexJ = 0;
        for(int i = 0; i < desktop.length; i++){
            for(int j = 0; j < desktop[i].length; j++){
                if(desktop[i][j] == 4){
                    arrayFours[0][indexJ] = i;
                    arrayFours[1][indexJ] = j;
                    indexJ = indexJ + 1;
                }
            }
        }
        System.out.println();

        for(int i = 0; i < arrayFours.length; i++){
            for(int j = 0; j < arrayFours[i].length; j++){
                System.out.print(arrayFours[i][j] + " ");
            }
            System.out.println();
        }
    }

    public void move(String direction) {
        //System.out.println(direction);


            switch (direction) {
                case "Left":
                    //System.out.println("Left");
                    moveLeft();
                    break;
                case "Right":
                    //System.out.println("Right");
                    moveRight();
                    break;
                case "Up":
                    //System.out.println("Up");
                    moveUp();
                    break;
                case "Down":
                    //System.out.println("Down");
                    moveDown();
                    break;
                default:
                    return;

            }
            checkGoal();
            viewer.update();
            won();
        }

    private void won() {

        boolean isWon = true;
        for (int j = 0; j < arrayFours[0].length; j++){
            int x = arrayFours[0][j];
            int y = arrayFours[1][j];
            if(desktop[x][y] != 3){
                isWon = false;
                break;

            }
        }
        if(isWon){
            javax.swing.JOptionPane.showMessageDialog(new javax.swing.JFrame(), "You won!!!");
            desktop = new int[][]{
                    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
                    {2, 0, 0, 0, 0, 0, 0, 0, 0, 2},
                    {2, 0, 0, 0, 0, 0, 3, 4, 0, 2},
                    {2, 0, 0, 0, 0, 0, 0, 0, 0, 2},
                    {2, 0, 0, 0, 0, 3, 0, 0, 0, 2},
                    {2, 0, 0, 0, 0, 4, 0, 0, 0, 2},
                    {2, 0, 0, 0, 0, 0, 0, 0, 0, 2},
                    {2, 0, 1, 0, 0, 0, 0, 0, 0, 2},
                    {2, 0, 0, 0, 0, 0, 0, 0, 0, 2},
                    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
            };
            initialization();
            viewer.update();
        }
    }
    private void checkGoal() {
//        if (desktop[indexX_4_1][indexY_4_1] == 0) {
//            desktop[indexX_4_1][indexY_4_1] = 4;
//        }
//        if (desktop[indexX_4_2][indexY_4_2] == 0) {
//            desktop[indexX_4_2][indexY_4_2] = 4;
//        }
        for (int j = 0; j < arrayFours[0].length; j++){
            int x = arrayFours[0][j];
            int y = arrayFours[1][j];
            if(desktop[x][y] == 0){
                desktop[x][y] = 4;
                break;
            }
        }
    }

    private void moveDown() {
        if (desktop[indexX + 1][indexY ] == 3) {
            if (desktop[indexX + 2][indexY] == 0 || desktop[indexX + 2][indexY] == 4) {
                desktop[indexX + 1][indexY] = 0;
                desktop[indexX + 2][indexY] = 3;
            }
        }
        if(desktop[indexX + 1][indexY] == 0 || desktop[indexX + 1][indexY] == 4){
            desktop[indexX][indexY] = 0;
            indexX = indexX + 1;
            desktop[indexX][indexY] = 1;
        }
    }

    private void moveUp() {
        if (desktop[indexX - 1][indexY ] == 3) {
            if (desktop[indexX - 2][indexY] == 0 || desktop[indexX - 2][indexY] == 4) {
                desktop[indexX - 1][indexY] = 0;
                desktop[indexX - 2][indexY] = 3;
            }
        }
        if(desktop[indexX - 1][indexY] == 0 || desktop[indexX - 1][indexY] == 4){
            desktop[indexX][indexY] = 0;
            indexX = indexX - 1;
            desktop[indexX][indexY] = 1;
        }
    }
    private void moveRight() {
        if (desktop[indexX][indexY + 1] == 3) {
            if (desktop[indexX][indexY + 2] == 0 || desktop[indexX][indexY + 2] == 4) {
                desktop[indexX][indexY + 1] = 0;
                desktop[indexX][indexY + 2] = 3;
            }
        }
        if(desktop[indexX][indexY + 1] == 0 || desktop[indexX][indexY + 1] == 4){
            if(desktop[indexX][indexY + 1] == 4){
                desktop[indexX][indexY] = 0;
                indexY = indexY + 1;
                desktop[indexX][indexY] = 44;
            }else {
                desktop[indexX][indexY] = 0;
                indexY = indexY + 1;
                desktop[indexX][indexY] = 1;
            }
        }
    }

    private void moveLeft() {
        if (desktop[indexX][indexY - 1] == 3) {
            if (desktop[indexX][indexY - 2] == 0 || desktop[indexX][indexY - 2] == 4) {
                desktop[indexX][indexY - 1] = 0;
                desktop[indexX][indexY - 2] = 3;
            }
        }
        if(desktop[indexX][indexY - 1] == 0 || desktop[indexX][indexY - 1] == 4){
            if(desktop[indexX][indexY - 1] == 4){
                desktop[indexX][indexY] = 0;
                indexY = indexY - 1;
                desktop[indexX][indexY] = 44;
            }else {
                desktop[indexX][indexY] = 0;
                indexY = indexY - 1;
                desktop[indexX][indexY] = 1;
            }
        }
    }
    public int[][] getDesktop(){
        return desktop;
    }
    public boolean getStateModel(){
        return stateModel;
    }
//    public int getX(){
//        return x;
//    }
//    public int getY(){
//        return y;
//    }
//    public int getWidth(){
//        return width;
//    }
//    public int getHeight(){
//        return height;
//    }
}

