import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Controller implements KeyListener {

    private Model model;

    public Controller(Viewer viewer){
        model = new Model(viewer);


    }
    public Model getModel(){
        return model;
    }
    public void keyTyped(KeyEvent event){
        System.out.println(event);

    }

    public void keyPressed(KeyEvent event){
        int keyCode = event.getKeyCode();
        String direction = "";
        switch (keyCode){
            case 37:
                direction = "Left";
                //System.out.println("Left");
                break;
            case 38:
                direction = "Up";
                //System.out.println("Up");
                break;
            case 39:
                direction = "Right";
                //System.out.println("Right");
                break;
            case 40:
                direction = "Down";
                //System.out.println("Down");
                break;
                default:
                    return;
        }
        //System.out.println(direction);
        model.move(direction);
//        if(keyCode <37 || 40 < keyCode){
//            return;
//        }
//        if (keyCode == 37){
//            System.out.println("Left");
//
//        }else if (keyCode == 38){
//            System.out.println("Up");
//        }else if (keyCode == 39){
//            System.out.println("Right");
//        }else if (keyCode == 40){
//            System.out.println("Down");
//        }
//        System.out.println("Bishkek");
   }

        public void keyReleased(KeyEvent event) {

        }

}
