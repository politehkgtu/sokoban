import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.Image;
import java.awt.Font;

public class Canvas extends JPanel {

    private Model model;
    private Image imageGamer;
    private Image imageWall;
    private Image imageBox;
    private Image imageGoal;
    private Image imageGoalOnGoal;
    private Image imageError;

    public Canvas(Model model) {
        this.model = model;
        setBackground(Color.BLACK);

        File fileGamer = new File("images/gamer.png");
        File fileWall = new File("images/wall.png");
        File fileBox = new File("images/box.png");
        File fileGoal = new File("images/goal.png");
        File fileGoalOnGoal = new File("images/gamerOnGoal.png");
        File fileError = new File("images/error.png");

        try {
            imageGamer = ImageIO.read(fileGamer);
            imageWall = ImageIO.read(fileWall);
            imageBox = ImageIO.read(fileBox);
            imageGoal = ImageIO.read(fileGoal);
            imageGoalOnGoal = ImageIO.read(fileGoalOnGoal);
            imageError = ImageIO.read(fileError);
        } catch (IOException ioe) {
            System.out.println("Error " + ioe);
        }
    }

    public void paint(Graphics g) {
        super.paint(g);
        if(model.getStateModel()) {
            drawDesktop(g);
        } else {
            drawError(g);
        }
    }

    private void drawError(Graphics g) {
        Font font = new Font("Impact", Font.BOLD, 70);
        g.setFont(font);
        g.setColor(Color.RED);
        g.drawString("Initialization Error!", 50, 100);
        g.drawImage(imageError, 100, 200, null);
    }
    private void drawDesktop(Graphics g) {
        super.paint(g);
        int[][] desktop = model.getDesktop();
        int x = 50;
        int y = 50;
        int width = 50;
        int height = 50;
        int offset = 0;

        for(int i = 0; i < desktop.length; i++) {
            for(int j = 0; j < desktop[i].length; j++) {
                if (desktop[i][j] == 1) {
                    g.drawImage(imageGamer, x, y, null);
                } else if (desktop[i][j] == 2) {
                    g.drawImage(imageWall, x, y, null);
                } else if (desktop[i][j] == 3) {
                    g.drawImage(imageBox, x, y, null);
                } else if (desktop[i][j] == 4) {
                    g.drawImage(imageGoal, x, y, null);
                } else if (desktop[i][j] == 44) {
                    g.drawImage(imageGoalOnGoal, x, y, null);
                } else if (desktop[i][j] == 5) {
                    g.setColor(Color.GREEN);
                    g.fillRect(x, y, width, height);
                } else {
                    g.setColor(Color.WHITE);
                    g.fillRect(x, y, width, height);
                }
                x = x + width + offset;
            }
            x = 50;
                y = y + height + offset;
            }
        }
    }
//}
//import javax.swing.*;
//import java.awt.*;
//
////import java.io.File;
////import java.io.IOException;
////import java.awt.Image;
////import javax.imageio.ImageIO;
//
//public class Canvas extends JPanel {
//
//    private Model model;
//    private Image imageGamer;
//
//    public Canvas(Model model){
//        this.model = model;
//        setBackground(Color.BLACK);
//
////        File fileGamer = new File("images/gamer.png");
////
////        try{
////            imageGamer = ImageIO.read(fileGamer);
////        }catch (IOException e){
////            System.out.println("Error: " + e);
////        }
//    }
//    public void paint(Graphics g){
//        super.paint(g);
//
//        int[][] desktop = model.getDesktop();
//        int x = 50;
//        int y = 50;
//        int width = 50;
//        int height = 50;
//        int offset = 5;
//
//        for (int i = 0; i < desktop.length; i ++){
//            for (int j = 0; j < desktop[i].length; j ++){
//                if(desktop[i][j] == 1){
//                    g.setColor(Color.RED);
//                    g.fillRect(x, y, width, height);
//                    g.setColor(Color.WHITE);
//                    g.drawRect(x, y, width, height);
//
//                }else if(desktop[i][j] == 2){
//                    g.setColor(Color.BLUE);
//                    g.fillRect(x, y, width, height);
//                    g.setColor(Color.WHITE);
//                    g.drawRect(x, y, width, height);
//                }else if(desktop[i][j] == 3){
//                    g.setColor(Color.GREEN);
//                    g.fillRect(x, y, width, height);
//                    g.setColor(Color.WHITE);
//                    g.drawRect(x, y, width, height);
//                }
//
//                else {
//                    g.setColor(Color.WHITE);
//                    g.drawRect(x, y, width, height);
//                }
//                x = x + width + offset;
//            }
//            x = 50;
//            y = y + height + offset;
//        }
//
//////        g.setColor(Color.RED);
//////        g.drawRect(250, 100, 150, 150);
//////
//////        g.setColor(Color.YELLOW);
//////        g.drawRect(250, 100, 150, 150);
//
//
////        g.drawRect(model.getX(), model.getY(), model.getWidth(), model.getHeight());
////        g.drawImage(imageGamer, model.getX(), model.getY(), null);
//
//////        System.out.println("I am Canvas object");
//////        System.out.println("paint(Graphics g");
//
//    }
//}
